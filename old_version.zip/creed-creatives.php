<?php
/**
 * Plugin Name: CreedCreatives Dashboard
 * Plugin URI: #
 * Description: Create a custom Dashboard and give the WordPress admin area a more meaningful use.
 * Version: 3.8.9
 * Author: Creed Creatives
 * Author URI: #
 * Text Domain: Creed Creatives Dashboard
 *
 * @package Creed Creatives Dashboard
 */

defined('ABSPATH') || die("Can't Access Directly");

define('CC_PLUGIN_DIR', rtrim( plugin_dir_path(__FILE__), '/' ));
define('CC_PLUGIN_URL', rtrim( plugin_dir_url(__FILE__). '/' ));
define('CC_PLUGIN_VERSION', '1.0.0');
define('CC_PLUGIN_FILE', plugin_basename(__FILE__));


require_once __DIR__ . '/modules/admin-menu/inc/not-doing-ajax.php';
// Helper classes.
require __DIR__ . '/helpers/class-screen-helper.php';
require __DIR__ . '/helpers/class-color-helper.php';
require __DIR__ . '/helpers/class-widget-helper.php';
require __DIR__ . '/helpers/class-content-helper.php';
require __DIR__ . '/helpers/class-user-helper.php';
require __DIR__ . '/helpers/class-array-helper.php';
require __DIR__ . '/helpers/class-admin-bar-helper.php';

// Base module.
require __DIR__ . '/modules/base/class-base-module.php';
require __DIR__ . '/modules/base/class-base-output.php';

// Core classes.
require __DIR__ . '/class-backwards-compatibility.php';
require __DIR__ . '/class-vars.php';
require __DIR__ . '/class-setup.php';

Ccd\Backwards_Compatibility::init();
Ccd\Setup::init();