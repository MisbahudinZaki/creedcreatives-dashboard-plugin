<?php

namespace Ccd;

defined('ABSPATH') || die("Can't access directly");

class Backwards_Compatibility{
    
	/**
	 * The class instance.
	 *
	 * @var object
	 */
    public static $instance;

    	/**
	 * Get instance of the class.
	 */
    public static function get_instance(){
        if (null === self::$instance) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
	 * Init the class setup.
	 */
	public static function init() {
		$instance = new Backwards_Compatibility();
		$instance->setup();
	}

    /**
	 * Setup the class.
	*/

    public function setup(){
        add_action('ccd_compat_widget_type', array( $this, 'parse_widget_type' ));
        add_action('admin_init', array($this, 'meta_compatibility'));
    }

    	/**
	 * Handle ccd_widget_type.
	 *
	 * Can be used for "whole checking" or "partial checking".
	 *
	 * @param int $post_id The post ID.
	 */

    public function parse_widget_type($post_id){
        $widget_type = get_post_meta( $post_id, 'ccd_widget_type' );

        if ( ! $widget_type ){
            $html = get_post_meta($post_id, 'ccd_html', true);
            $content = get_post_meta($post_id, 'ccd_content', true);

            if ( $html ) {
				$widget_type = 'html';
			} elseif ( $content ) {
				$widget_type = 'text';
			} else {
				$widget_type = 'icon';
			}

            $widget_type = apply_filters('ccd_parse_widget_type', $widget_type, $post_id);
            update_post_meta($post_id, 'ccd_widget_type', $widget_type);
        }
    }

    /**
	 * Run compatibility checking on admin_init hook.
	 */
	public function meta_compatibility() {

		// Don't run checking on heartbeat request.
		if ( isset( $_POST['action'] ) && 'heartbeat' === $_POST['action'] ) {
			return;
		}

		$this->delete_old_options();
		$this->check_widget_type();
		$this->check_widget_status();
		$this->replace_submeta_keys();
		$this->delete_unused_page();

		do_action( 'ccd_meta_compatibility' );

	}

    /**
	 * Delete old options and move their value to $ccd_settings.
	 */
    public function delete_old_options(){
        if ( get_option('ccd_compat_old_option') ){
            return;
        }

        $ccd_settings = get_option('ccd_settings', array() );

        if (! $ccd_settings){
            update_option('ccd_settings', array());
        }

        if ( isset( $ccd_settings['remove_admin_bar'] ) && ! is_array( $ccd_settings['remove_admin_bar'] ) ) {
			/**
			 * The previous format was just checkbox,
			 * so we need to convert it to new format which is array (by roles).
			 */
			$ccd_settings['remove_admin_bar'] = [ 'all' ];
			update_option( 'ccd_settings', $ccd_settings );
		}

        if ( get_option( 'removeallwidgets' ) ) {
			$ccd_settings['remove-all'] = 1;
			update_option( 'ccd_settings', $ccd_settings );
			delete_option( 'removeallwidgets' );
		}

        if ( get_option('welcome')){
            $ccd_settings['welcome_panel'] = 1;
            update_option('ccd_settings', $ccd_settings);
            delete_option('welcome');
        }

        if ( get_option('primary')){
            $ccd_settings['dashboard_primary'] = 1;
            update_option('ccd_settings', $ccd_settings);
            delete_options('primary');
        }

        if ( get_option('quickpress')){
            $ccd_settings['dashboard_quick_press'] = 1;
            update_option('ccd_settings', $ccd_settings);
            delete_options('quickpress');
        }

        if ( get_option( 'activity' ) ) {
			$ccd_settings['dashboard_activity'] = 1;
			update_option( 'ccd_settings', $udb_settings );
			delete_option( 'activity' );
		}

		if ( get_option( 'incominglinks' ) ) {
			$ccd_settings['dashboard_incoming_links'] = 1;
			update_option( 'ccd_settings', $ccd_settings );
			delete_option( 'incominglinks' );
		}

		if ( get_option( 'plugins' ) ) {
			$ccd_settings['dashboard_plugins'] = 1;
			update_option( 'ccd_settings', $udb_settings );
			delete_option( 'plugins' );
		}

		if ( get_option( 'secondary' ) ) {
			$ccd_settings['dashboard_secondary'] = 1;
			update_option( 'ccd_settings', $ccd_settings );
			delete_option( 'secondary' );
		}

		if ( get_option( 'drafts' ) ) {
			$ccd_settings['dashboard_recent_drafts'] = 1;
			update_option( 'ccd_settings', $udb_settings );
			delete_option( 'drafts' );
		}

		if ( get_option( 'comments' ) ) {
			$ccd_settings['dashboard_recent_comments'] = 1;
			update_option( 'ccd_settings', $udb_settings );
			delete_option( 'comments' );
		}

		do_action( 'udb_delete_old_options' );

        update_action('ccd_compat_old_option', 1);
    }

    /**
	 * Whole checking udb_widget_type compatibility.
	 */
	public function check_widget_type() {

		// Make sure we don't check again.
		if ( get_option( 'ccd_compat_widget_type' ) ) {
			return;
		}

		$widgets = get_posts(
			array(
				'post_type'   => 'ccd_widgets',
				'numberposts' => -1,
				'post_status' => 'any',
			)
		);

		if ( ! $widgets ) {
			return;
		}

		foreach ( $widgets as $widget ) {
			do_action( 'ccd_compat_widget_type', $widget->ID );
		}

		// Make sure we don't check again.
		update_option( 'ccd_compat_widget_type', 1 );

	}

    /**
	 * Whole checking udb_widget_status compatibility.
	 */
	public function check_widget_status() {

		// Make sure we don't check again.
		if ( get_option( 'ccd_compat_widget_status' ) ) {
			return;
		}

		$widgets = get_posts(
			array(
				'post_type'   => 'ccd_widgets',
				'numberposts' => -1,
				'post_status' => 'any',
			)
		);

		if ( ! $widgets ) {
			// Make sure we don't check again.
			update_option( 'ccd_compat_widget_status', 1 );

			return;
		}

		foreach ( $widgets as $widget ) {
			update_post_meta( $widget->ID, 'ccd_is_active', 1 );
		}

		// Make sure we don't check again.
		update_option( 'ccd_compat_widget_status', 1 );

	}

    /**
	 * Move udb_pro_settings to udb_settings.
	 */
	public function replace_submeta_keys() {

		// Make sure we don't check again.
		if ( get_option( 'ccd_compat_settings_meta' ) ) {
			return;
		}

		$setting_opts = get_option( 'ccd_settings', array() );

		$update_setting_opts = false;

		// Dashboard's custom css.
		if ( isset( $pro_opts['custom_css'] ) ) {
			$setting_opts['custom_css'] = $pro_opts['custom_css'];
			$update_setting_opts        = true;

			unset( $pro_opts['custom_css'] );
		}

		// Update the settings meta if necessary.
		if ( $update_setting_opts ) {
			update_option( 'ccd_settings', $setting_opts );
		}

		do_action( 'ccd_replace_submeta_keys' );

		// // Delete ccd_pro_settings, since we don't use it anymore.
		// delete_option( 'udb_pro_settings' );

		// Make sure we don't check again.
		update_option( 'ccd_compat_settings_meta', 1 );

	}

    public function delete_unused_page() {

		// Make sure we don't check again.
		if ( get_option( 'ccd_compat_delete_login_customizer_page' ) ) {
			return;
		}

		$page = get_page_by_path( 'ccd-login-page' );

		if ( ! empty( $page ) && is_object( $page ) ) {
			wp_delete_post( $page->ID, true );
		}

		// Make sure we don't check again.
		update_option( 'ccd_compat_delete_login_customizer_page', 1 );

	}
    
}