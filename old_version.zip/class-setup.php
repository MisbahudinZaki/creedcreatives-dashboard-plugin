<?php

/**
 * Setup Creed Creatives Dashboard plugin.
 *
 * @package Creed_Creatives_Dashboard
 */

namespace Ccd;

defined('ABSPATH') ||die("Can't access directly");

use Ccd\Vars;
use Ccd\Helpers\Content_Helper;

class Setup {
    /**
	 * The class instanace
	 *
	 * @var object
	 */
    public static $instance = null;

    public static function get_instance(){
        if (null === self::$instance){
            self::$instance = new self();
        }
        return self::$instance;
    }

      /**
	 * Init the class setup.
	 */
	public static function init() {
		$instance = new Setup();
		$instance->setup();
	}

    /**
	 * Get saved/default modules.
	 *
	 * @return array The saved/default modules.
	 */

    public function saved_modules(){
        $defaults = array(
            'white_label'       => 'true',
            'login_customizer'  => 'true',
            'login_redirect'    => 'true',
            'admin_pages'       => 'true',
            'admin_menu_editor' => 'true',
            'admin_bar_editor'  => 'true',
        );

        $saved_modules = get_option('ccd_modules', $defaults);
        $new_modules = array_diff_key($defaults, $saved_modules);

        if ( ! empty($new_modules)){
            $updated_modules = array_merge($saved_modules, $new_modules);
            update_option('ccd_modules', $updated_modules);
        }

        return apply_filters('ccd_saved_modules', get_option('ccd_modules', $defaults));
    }

    /**
	 * Setup the class.
	 */
	public function setup() {

		register_activation_hook( CC_PLUGIN_FILE, array( $this, 'on_plugin_activation' ), 20 );

		add_action( 'plugins_loaded', array( $this, 'load_modules' ), 20 );
		add_action( 'plugins_loaded', array( $this, 'load_plugin_onboarding_module' ), 20 );
		add_action( 'plugins_loaded', array( $this, 'load_onboarding_wizard_module' ), 20 );

		add_action( 'init', array( self::get_instance(), 'check_activation_meta' ) );
		add_action( 'admin_menu', array( $this, 'pro_submenu' ), 20 );
		add_filter( 'admin_body_class', array( $this, 'admin_body_class' ), 20 );
		add_filter( 'plugin_action_links_' . CC_PLUGIN_FILE, array( $this, 'action_links' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ), 20 );
		add_action( 'admin_notices', array( self::get_instance(), 'review_notice' ) );
		add_action( 'admin_notices', array( self::get_instance(), 'bfcm_notice' ) );
		add_action( 'wp_ajax_ccd_dismiss_review_notice', array( $this, 'dismiss_review_notice' ) );
		add_action( 'wp_ajax_ccd_dismiss_bfcm_notice', array( $this, 'dismiss_bfcm_notice' ) );

		register_deactivation_hook( CC_PLUGIN_FILE, array( $this, 'deactivation' ), 20 );

		$content_helper = new Content_Helper();
		add_filter( 'wp_kses_allowed_html', array( $content_helper, 'allow_iframes_in_html' ) );

   }

   /**
	 * Preload CCD settings.
	 * This will reduce the repeated call of get_option across modules.
	 *
	 * @deprecated 3.7.15 Not good for performance. This method was called both in admin & front area. The benefits were not much, because there was only few places where the preloaded data was re-used.
	 */
	public function set_data() {}

    /**
	 * Check plugin activation meta.
	 */
	public function check_activation_meta() {

		if ( ! current_user_can( 'activate_plugins' ) || get_option( 'ccd_plugin_activated' ) ) {
			return;
		}

		update_option( 'ccd_install_date', current_time( 'mysql' ) );
		update_option( 'ccd_plugin_activated', 1 );

	}

    /**
	 * Admin body class.
	 *
	 * @param string $classes The class names.
	 */
    public function admin_body_class( $classes ){
        $current_user = wp_get_current_user();
        $classes .= ' ccd_user- ' . $current_user->user_nicename;

        $roles = $current_user->roles;
        $roles = $roles ? $roles : array();

        foreach( $roles as $role ) {
            $classes .= ' ccd_role ' . $role;
        }

        $screens = array(
			'ccd_widgets_page_ccd_features',
			'ccd_widgets_page_ccd-license',
			'ccd_widgets_page_ccd_tools',
			'ccd_widgets_page_ccd_branding',
			'ccd_widgets_page_ccd_settings',
			'ccd_widgets_page_ccd_login_redirect',
			'ccd_widgets_page_ccd_admin_menu',
			'ccd_widgets_page_ccd_admin_bar',
			'ccd_widgets_page_ccd_plugin_onboarding',
			'ccd_widgets_page_ccd_onboarding_wizard',
		);

		$screen = get_current_screen();

		if ( ! in_array( $screen->id, $screens, true ) ) {
			return $classes;
		}

		$classes .= ' heatbox-admin has-header';

		return $classes;

	}

    /**
	 * Add action links displayed in plugins page.
	 *
	 * @param array $links The action links array.
	 * @return array The modified action links array.
	 */

    public function action_links( $links ) {

		$settings = array( '<a href="' . admin_url( 'edit.php?post_type=ccd_widgets&page=ccd_settings' ) . '">' . __( 'Settings', 'ultimate-dashboard' ) . '</a>' );

		return array_merge( $links, $settings );

	}

    /**
	 * Store an option that tracks the plugin activation.
	 */
    public function on_plugin_activation(){
        // Stop if this is activation from Erident's migration to ccd.
		if ( get_option( 'ccd_migration_from_erident' ) ) {
			// Prevent "Setup Wizard" from being shown for Erident's users.
			update_option( 'ccd_onboarding_wizard_completed', 1 );
			return;
		}

		// // We bail out early in multisite because this function will still be called in the main site.
		// if ( is_multisite() || ccd_is_pro_active() ) {
		// 	return;
		// }

		update_option( 'ccd_onboarding_wizard_redirect', 1 );

    }

    /**
	 * Load Creed Creatives Dashboard modules.
	 */
	public function load_modules(){
		
	}
}